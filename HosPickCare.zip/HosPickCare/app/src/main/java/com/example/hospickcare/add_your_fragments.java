package com.example.hospickcare;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.hospickcare.R;
import com.example.hospickcare.Savings;

public class add_your_fragments extends Fragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstenceState){
        View view=inflater.inflate(R.layout.fragment_add__your__savings,container,false);
        Button btnFragment=(Button)view.findViewById(R.id.button5);
        btnFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fr=getChildFragmentManager().beginTransaction();
                fr.replace(R.id.fragment_container_view_tag,new Savings());
                fr.commit();
            }
        });

        return view;
    }
}
