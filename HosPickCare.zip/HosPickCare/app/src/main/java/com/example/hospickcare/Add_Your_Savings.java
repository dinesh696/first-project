package com.example.hospickcare;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;



public class Add_Your_Savings extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_add__your__savings,container,false);
        // Inflate the layout for this fragment
        Button btnFragment=(Button)view.findViewById(R.id.button3);
        btnFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fr=getChildFragmentManager().beginTransaction();
                fr.replace(R.id.fragment_container_view_tag,new Your_Savings());
                fr.commit();

            }
        });
       return view;
    }
}
