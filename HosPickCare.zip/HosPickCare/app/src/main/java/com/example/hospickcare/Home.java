package com.example.hospickcare;

import android.os.Bundle;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;




public class Home extends Fragment {
    private EditText enteryouremailidandupiid2,num;
    private Button done;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        // Inflate the layout for this fragment
        num = (EditText) num.findViewById(R.id.editText4);
        enteryouremailidandupiid2 = (EditText) enteryouremailidandupiid2.findViewById(R.id.editText6);
        done = (Button) done.findViewById(R.id.button4);



        //performing action on button click
        done.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                String no=num.getText().toString();
                String msg=enteryouremailidandupiid2.getText().toString();


                //Getting Intent and PendingIntent instance
                Intent intent=new Intent(getContext(),MainActivity.class);
                PendingIntent pi=PendingIntent.getActivity(getContext(), 0, intent,0);

                //Get the SmsManager instance and call the sendTextMessage method to send message
                SmsManager sms=SmsManager.getDefault();
                sms.sendTextMessage(no, null, msg, pi,null);

                Toast.makeText(getContext(), "completed successfully!",
                        Toast.LENGTH_LONG).show();
            }
        });


        return view;
    }
}
