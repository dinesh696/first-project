package com.example.hospickcare;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class pageadapter extends FragmentStatePagerAdapter {
int counttab;
    public pageadapter(FragmentManager fm, int counttab) {
        super(fm, counttab);
        this.counttab = counttab;
    }

    @NonNull
    @Override
    public Fragment getItem(int i) {
        switch (i){
            case 0:
                info info = new info();
                return info;
            case 1:
                Add_Your_Savings add_your_savings = new Add_Your_Savings();
                return add_your_savings;
            case 2:
                amount amount = new amount();
                return amount;
            default:
                return null;


        }
    }

    @Override
    public int getCount() {
        return counttab;
    }
}
