package com.example.hospickcare;

import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.sql.Connection;
import java.util.ArrayList;


public class amount<container> extends Fragment {
    private ListView listView;
    ArrayAdapter<String> adapter;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_amount, container, false);

        listView = (ListView) listView.findViewById(R.id.listView);
        ArrayAdapter  adapter = new ArrayAdapter(getContext(),android.R.layout.simple_list_item_1);
        listView.setAdapter(adapter);
        new Connection().execute();
        return view;

    }

    class  Connection extends AsyncTask<String,String,String> {
        @Override
        protected  String doInBackground(String...params){
            String result = "";
            String host = "http://localhost/store/amounts.php";
            try {
                HttpClient client = (HttpClient) new HttpGet();
                HttpGet request = new HttpGet();
                request.setURI(new URI(host));
                HttpResponse response = client.execute(request);
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

                StringBuffer stringBuffer = new StringBuffer("");

                String line = "";
                while ((line = reader.readLine()) !=null){
                    stringBuffer.append(line);
                    break;
                }
                reader.close();
                result = stringBuffer.toString();

            }
            catch (Exception e){
                return new String("There exception:" + e.getMessage());


            }

            return result;
        }
        @Override
        protected void onPostExecute(String result){
            try {
                JSONObject jsonresult = new JSONObject(result);
                int success = jsonresult.getInt("success");
                if(success==1){
                    JSONArray amounts = jsonresult.getJSONArray("amount");
                    for (int i=0; 1 < amounts.length(); i ++){
                        JSONObject amount = amounts.getJSONObject(i);
                        String patientname = amount.getString("patient name");
                        String hospitelname = amount.getString("hospital name");
                        String hospitaladdress = amount.getString("hopital address");
                        double amountsend = amount.getDouble("amount");
                        String line =  patientname+"-"+hospitelname+"-"+hospitaladdress+"-"+amountsend;
                        adapter.add(line);
                    }
                }
                else {
                    Toast.makeText(getContext(),"There is no amount yet",Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
            }
        }

    }
    }

