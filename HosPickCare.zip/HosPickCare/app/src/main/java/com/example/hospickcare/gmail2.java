package com.example.hospickcare;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

public class gmail2 extends Fragment {
    private EditText mEditTextId;
    private EditText mEditTextSub;
    private EditText mEditTextMess;
    private Button next;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        mEditTextId = mEditTextId.findViewById(R.id.edit_text_to);
        mEditTextSub= mEditTextSub.findViewById(R.id.edit_text_subject);
        mEditTextMess = mEditTextMess.findViewById(R.id.edit_text_message);

        next = next.findViewById(R.id.button_next);
        next.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendMail();

            }
        });
        return view;

    }


    private void sendMail(){
        String recipientList = mEditTextId.getText().toString();
        String[] recipients = recipientList.split(",");

        String subject = mEditTextSub.getText().toString();
        String message = mEditTextMess.getText().toString();

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.putExtra(Intent.EXTRA_EMAIL,recipients);
        intent.putExtra(Intent.EXTRA_SUBJECT,subject);
        intent.putExtra(Intent.EXTRA_TEXT,message);

        intent.setType("message/rfc822");
        startActivity(Intent.createChooser(intent, "choose an email client"));

    }

}
